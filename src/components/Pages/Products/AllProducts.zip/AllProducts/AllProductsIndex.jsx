import { useEffect, useMemo, useRef, useState } from "react";
import { SlidersHorizontal } from "lucide-react";
import { allProducts, getCategories } from "./allProductsData";
import ProductsHero from "./components/ProductsHero";
import BreadcrumbBar from "./components/BreadcrumbBar";
import CategorySidebar from "./components/CategorySidebar";
import SearchSortBar from "./components/SearchSortBar";
import ProductGrid from "./components/ProductGrid";
import CataloguePagination from "./components/CataloguePagination";
import MobileFilterDrawer from "./components/MobileFilterDrawer";
import BrandStatement from "./components/BrandStatement";
import "./AllProducts.css";

const PAGE_SIZE = 12;
const DEBOUNCE_MS = 300;
const TRANSITION_MS = 250;

const AllProductsIndex = () => {
  const categories = useMemo(() => getCategories(allProducts), []);

  const [activeCategory, setActiveCategory] = useState(null);
  const [searchInput, setSearchInput] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [sortBy, setSortBy] = useState("latest");
  const [page, setPage] = useState(1);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState(false);

  const transitionTimeoutRef = useRef(null);

  // Debounce the free-text search so filtering doesn't re-run on every keystroke.
  useEffect(() => {
    const timer = setTimeout(() => setDebouncedSearch(searchInput), DEBOUNCE_MS);
    return () => clearTimeout(timer);
  }, [searchInput]);

  useEffect(() => {
    return () => {
      if (transitionTimeoutRef.current) clearTimeout(transitionTimeoutRef.current);
    };
  }, []);

  // Brief, deliberate transition so filter/sort/page changes feel considered rather than instant.
  const triggerTransition = () => {
    setIsTransitioning(true);
    if (transitionTimeoutRef.current) clearTimeout(transitionTimeoutRef.current);
    transitionTimeoutRef.current = setTimeout(() => setIsTransitioning(false), TRANSITION_MS);
  };

  const filteredProducts = useMemo(() => {
    const term = debouncedSearch.trim().toLowerCase();

    const filtered = allProducts.filter((product) => {
      const matchesCategory = !activeCategory || product.category === activeCategory;
      const matchesSearch =
        !term ||
        product.name.toLowerCase().includes(term) ||
        product.category.toLowerCase().includes(term) ||
        (product.color && product.color.toLowerCase().includes(term));

      return matchesCategory && matchesSearch;
    });

    const sorted = [...filtered];
    if (sortBy === "name-asc") {
      sorted.sort((a, b) => a.name.localeCompare(b.name));
    } else if (sortBy === "name-desc") {
      sorted.sort((a, b) => b.name.localeCompare(a.name));
    } else {
      // "Latest" — most recently catalogued first.
      sorted.reverse();
    }

    return sorted;
  }, [activeCategory, debouncedSearch, sortBy]);

  const totalPages = Math.max(1, Math.ceil(filteredProducts.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);

  const paginatedProducts = useMemo(() => {
    const start = (currentPage - 1) * PAGE_SIZE;
    return filteredProducts.slice(start, start + PAGE_SIZE);
  }, [filteredProducts, currentPage]);

  const rangeStart = filteredProducts.length === 0 ? 0 : (currentPage - 1) * PAGE_SIZE + 1;
  const rangeEnd = Math.min(currentPage * PAGE_SIZE, filteredProducts.length);

  const handleCategorySelect = (category) => {
    setActiveCategory(category);
    setPage(1);
    triggerTransition();
  };

  const handleSearchChange = (value) => {
    setSearchInput(value);
    setPage(1);
  };

  const handleSortChange = (value) => {
    setSortBy(value);
    setPage(1);
    triggerTransition();
  };

  const handlePageChange = (nextPage) => {
    setPage(nextPage);
    triggerTransition();
  };

  const handleClearFilters = () => {
    setActiveCategory(null);
    setSearchInput("");
    setSortBy("latest");
    setPage(1);
    triggerTransition();
  };

  return (
    <div className="bg-white">
      <ProductsHero />

      <BreadcrumbBar
        rangeStart={rangeStart}
        rangeEnd={rangeEnd}
        total={filteredProducts.length}
      />

      <div className="px-6 py-12 sm:px-10 md:px-16 md:py-16">
        <div className="flex items-center justify-between gap-4 md:hidden">
          <button
            type="button"
            onClick={() => setIsMobileFilterOpen(true)}
            className="flex items-center gap-2 border border-black/15 px-4 py-2.5 text-[12px] font-medium tracking-[0.15em] text-[#1a1a1a] uppercase"
          >
            <SlidersHorizontal size={14} />
            Filter Products
          </button>
        </div>

        <div className="mt-6 grid grid-cols-1 gap-12 md:mt-0 md:grid-cols-[30%_70%] md:gap-14">
          <div className="hidden md:block">
            <CategorySidebar
              categories={categories}
              totalCount={allProducts.length}
              activeCategory={activeCategory}
              onSelect={handleCategorySelect}
            />
          </div>

          <div>
            <SearchSortBar
              searchTerm={searchInput}
              onSearchChange={handleSearchChange}
              sortBy={sortBy}
              onSortChange={handleSortChange}
            />

            <div className="mt-8">
              <ProductGrid
                products={paginatedProducts}
                isLoading={isTransitioning}
                onClearFilters={handleClearFilters}
              />
            </div>

            <CataloguePagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={handlePageChange}
            />
          </div>
        </div>
      </div>

      <BrandStatement />

      <MobileFilterDrawer
        open={isMobileFilterOpen}
        onClose={() => setIsMobileFilterOpen(false)}
        categories={categories}
        totalCount={allProducts.length}
        activeCategory={activeCategory}
        onSelect={handleCategorySelect}
        onClearAll={handleClearFilters}
      />
    </div>
  );
};

export default AllProductsIndex;
