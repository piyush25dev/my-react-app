import { catalogueData } from "../../../Data/Gallery";
import exoticData from "../../../Data/ExoticData";

// Display order for the category sidebar — the underlying counts and
// category names themselves are always derived from the real data below,
// never hard-coded.
const CATEGORY_ORDER = [
  "Elevation",
  "Exotic",
  "Quartz",
  "Onyx",
];

const normalizedCatalogue = catalogueData.map((product) => ({
  id: `stone-${product.id}`,
  name: product.name,
  image: product.image,
  description: product.description,
  category: product.category,
  color: product.color,
}));

const normalizedExotic = exoticData.map((product, index) => ({
  id: `exotic-${index}`,
  name: product.name,
  image: product.image,
  description: product.description,
  category: "Exotic",
  color: null,
}));

export const allProducts = [...normalizedCatalogue, ...normalizedExotic].sort(
  (a, b) => CATEGORY_ORDER.indexOf(a.category) - CATEGORY_ORDER.indexOf(b.category)
);

export function getCategories(products) {
  const counts = products.reduce((acc, product) => {
    acc[product.category] = (acc[product.category] || 0) + 1;
    return acc;
  }, {});

  return CATEGORY_ORDER.filter((name) => counts[name]).map((name) => ({
    name,
    count: counts[name],
  }));
}
