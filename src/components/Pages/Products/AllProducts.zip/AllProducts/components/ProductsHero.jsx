const ProductsHero = () => {
  return (
    <section className="relative h-[70vh] min-h-[480px] w-full overflow-hidden bg-black md:h-[80vh]">
      <img
        src="/Hero-image/07.png"
        alt="Vaastu Italian Marble showroom slab"
        className="ap-kenburns absolute inset-0 h-full w-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-black/55" />

      <div className="relative z-10 flex h-full w-full flex-col items-start justify-end px-6 pb-14 sm:px-10 md:items-center md:justify-center md:px-16 md:pb-0 md:text-center">
        <p className="mb-5 flex items-center gap-3 text-[11px] font-medium tracking-[0.35em] text-white/70">
          <span className="ap-gold-rule" />
          ALL PRODUCTS
        </p>

        <h1 className="font-display text-[13vw] leading-[0.98] font-medium text-white sm:text-[64px] md:text-[76px]">
          <span className="block">EXPLORE</span>
          <span className="block text-[#d9c19a]">OUR COLLECTION</span>
        </h1>

        <p className="mt-6 max-w-md text-[14px] leading-relaxed font-light text-white/80 md:text-[16px]">
          A curated selection of the world&rsquo;s finest natural stones,
          crafted for exceptional spaces.
        </p>

        <div className="mt-9 flex items-center gap-3 text-[11px] font-medium tracking-[0.3em] text-white/60 md:mt-11">
          <span>TIMELESS SURFACES</span>
          <span className="h-1 w-1 rounded-full bg-[#c6a97c]" />
          <span>INSPIRED SPACES</span>
        </div>
      </div>
    </section>
  );
};

export default ProductsHero;
