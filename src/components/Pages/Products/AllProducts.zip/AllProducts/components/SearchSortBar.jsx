import { Search } from "lucide-react";

const SORT_OPTIONS = [
  { value: "latest", label: "Latest" },
  { value: "name-asc", label: "Name A–Z" },
  { value: "name-desc", label: "Name Z–A" },
];

const SearchSortBar = ({ searchTerm, onSearchChange, sortBy, onSortChange }) => {
  return (
    <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
      <div className="relative w-full sm:max-w-sm">
        <Search
          size={16}
          className="pointer-events-none absolute top-1/2 left-4 -translate-y-1/2 text-[#8a7358]"
          aria-hidden="true"
        />
        <label htmlFor="product-search" className="sr-only">
          Search products, colours, or categories
        </label>
        <input
          id="product-search"
          type="search"
          value={searchTerm}
          onChange={(event) => onSearchChange(event.target.value)}
          placeholder="Search products, colours, or categories..."
          className="w-full border border-black/15 bg-white py-3 pr-4 pl-11 text-[13px] font-light text-[#1a1a1a] placeholder:text-[#a3a3a3] focus:border-[#c6a97c] focus:outline-none"
        />
      </div>

      <div className="flex items-center gap-3">
        <label
          htmlFor="product-sort"
          className="text-[12px] font-light tracking-wide text-[#5c564d]"
        >
          Sort by
        </label>
        <select
          id="product-sort"
          value={sortBy}
          onChange={(event) => onSortChange(event.target.value)}
          className="border border-black/15 bg-white px-4 py-3 text-[13px] font-light text-[#1a1a1a] focus:border-[#c6a97c] focus:outline-none"
        >
          {SORT_OPTIONS.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
};

export default SearchSortBar;
