import { ChevronLeft, ChevronRight } from "lucide-react";

const getPageList = (current, total) => {
  if (total <= 7) {
    return Array.from({ length: total }, (_, index) => index + 1);
  }

  const pages = new Set([1, 2, total - 1, total, current - 1, current, current + 1]);
  const sorted = [...pages].filter((page) => page >= 1 && page <= total).sort((a, b) => a - b);

  const withEllipsis = [];
  sorted.forEach((page, index) => {
    if (index > 0 && page - sorted[index - 1] > 1) {
      withEllipsis.push("ellipsis");
    }
    withEllipsis.push(page);
  });

  return withEllipsis;
};

const CataloguePagination = ({ currentPage, totalPages, onPageChange }) => {
  if (totalPages <= 1) return null;

  return (
    <nav
      aria-label="Product pagination"
      className="mt-14 flex items-center justify-center gap-2"
    >
      <button
        type="button"
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage === 1}
        aria-label="Previous page"
        className="flex h-9 w-9 items-center justify-center border border-black/15 text-[#5c564d] transition-colors duration-300 hover:border-[#c6a97c] disabled:cursor-not-allowed disabled:opacity-30 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#c6a97c]"
      >
        <ChevronLeft size={16} />
      </button>

      {getPageList(currentPage, totalPages).map((page, index) =>
        page === "ellipsis" ? (
          <span
            key={`ellipsis-${index}`}
            className="px-2 text-[13px] text-[#a3a3a3]"
            aria-hidden="true"
          >
            …
          </span>
        ) : (
          <button
            key={page}
            type="button"
            onClick={() => onPageChange(page)}
            aria-current={page === currentPage ? "page" : undefined}
            className={`flex h-9 w-9 items-center justify-center text-[13px] transition-colors duration-300 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#c6a97c] ${
              page === currentPage
                ? "bg-[#1a1a1a] font-medium text-white"
                : "text-[#5c564d] hover:bg-[#f5f4f2]"
            }`}
          >
            {page}
          </button>
        )
      )}

      <button
        type="button"
        onClick={() => onPageChange(currentPage + 1)}
        disabled={currentPage === totalPages}
        aria-label="Next page"
        className="flex h-9 w-9 items-center justify-center border border-black/15 text-[#5c564d] transition-colors duration-300 hover:border-[#c6a97c] disabled:cursor-not-allowed disabled:opacity-30 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#c6a97c]"
      >
        <ChevronRight size={16} />
      </button>
    </nav>
  );
};

export default CataloguePagination;
