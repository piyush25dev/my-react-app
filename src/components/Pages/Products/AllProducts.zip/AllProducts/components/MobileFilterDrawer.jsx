import { X } from "lucide-react";

const MobileFilterDrawer = ({
  open,
  onClose,
  categories,
  totalCount,
  activeCategory,
  onSelect,
  onClearAll,
}) => {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex md:hidden" role="dialog" aria-modal="true" aria-label="Filter products">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />

      <div className="relative ml-auto flex h-full w-full max-w-xs flex-col bg-white px-6 py-6">
        <div className="flex items-center justify-between">
          <h2 className="text-[13px] font-medium tracking-[0.2em] text-[#1a1a1a] uppercase">
            Filter Products
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close filters"
            className="flex h-8 w-8 items-center justify-center text-[#1a1a1a]"
          >
            <X size={18} />
          </button>
        </div>

        <div className="mt-6 flex-1 overflow-y-auto">
          <p className="mb-3 text-[11px] font-medium tracking-[0.2em] text-[#8a7358] uppercase">
            Categories
          </p>
          <ul className="flex flex-col">
            <li>
              <button
                type="button"
                onClick={() => onSelect(null)}
                aria-pressed={activeCategory === null}
                className={`flex w-full items-center justify-between border-l-2 px-3 py-3 text-left text-[13px] uppercase tracking-wide ${
                  activeCategory === null
                    ? "border-[#c6a97c] bg-[#f5f4f2] font-medium text-[#1a1a1a]"
                    : "border-transparent font-light text-[#5c564d]"
                }`}
              >
                <span>All Products</span>
                <span className="text-[12px] text-[#8a7358]">{totalCount}</span>
              </button>
            </li>
            {categories.map((category) => (
              <li key={category.name}>
                <button
                  type="button"
                  onClick={() => onSelect(category.name)}
                  aria-pressed={activeCategory === category.name}
                  className={`flex w-full items-center justify-between border-l-2 px-3 py-3 text-left text-[13px] uppercase tracking-wide ${
                    activeCategory === category.name
                      ? "border-[#c6a97c] bg-[#f5f4f2] font-medium text-[#1a1a1a]"
                      : "border-transparent font-light text-[#5c564d]"
                  }`}
                >
                  <span>{category.name}</span>
                  <span className="text-[12px] text-[#8a7358]">{category.count}</span>
                </button>
              </li>
            ))}
          </ul>
        </div>

        <div className="flex gap-3 border-t border-black/10 pt-5">
          <button
            type="button"
            onClick={onClearAll}
            className="flex-1 border border-black/15 px-2 py-3 text-[10px] font-medium tracking-[0.1em] whitespace-nowrap text-[#5c564d] uppercase"
          >
            Clear All
          </button>
          <button
            type="button"
            onClick={onClose}
            className="flex-1 bg-[#1a1a1a] px-2 py-3 text-[10px] font-medium tracking-[0.1em] whitespace-nowrap text-white uppercase"
          >
            Apply Filters
          </button>
        </div>
      </div>
    </div>
  );
};

export default MobileFilterDrawer;
