import StoneCard from "./StoneCard";

const SkeletonCard = () => (
  <div className="flex flex-col border border-black/10 bg-white" aria-hidden="true">
    <div className="ap-shimmer aspect-[4/5] w-full" />
    <div className="flex flex-col gap-3 px-5 py-5">
      <div className="ap-shimmer h-4 w-2/3" />
      <div className="ap-shimmer h-3 w-1/3" />
    </div>
  </div>
);

const ProductGrid = ({ products, isLoading, onClearFilters }) => {
  if (isLoading) {
    return (
      <div className="grid grid-cols-2 gap-5 sm:gap-6 md:grid-cols-3 lg:grid-cols-4">
        {Array.from({ length: 8 }).map((_, index) => (
          <SkeletonCard key={index} />
        ))}
      </div>
    );
  }

  if (products.length === 0) {
    return (
      <div className="flex flex-col items-center gap-4 border border-black/10 bg-white px-6 py-20 text-center">
        <p className="font-display text-[24px] font-medium tracking-wide text-[#1a1a1a]">
          NO STONES FOUND
        </p>
        <p className="text-[13px] font-light text-[#7a8792]">
          Try another search or category.
        </p>
        <button
          type="button"
          onClick={onClearFilters}
          className="group mt-2 inline-flex items-center gap-2 text-[12px] font-medium tracking-[0.15em] text-[#8a7358] uppercase focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#c6a97c]"
        >
          Clear Filters
          <span className="transition-transform duration-300 group-hover:translate-x-1">
            →
          </span>
        </button>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-5 sm:gap-6 md:grid-cols-3 lg:grid-cols-4">
      {products.map((product, index) => (
        <StoneCard key={product.id} product={product} index={index} />
      ))}
    </div>
  );
};

export default ProductGrid;
