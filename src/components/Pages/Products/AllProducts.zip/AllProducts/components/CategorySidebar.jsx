import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";

const CategorySidebar = ({ categories, totalCount, activeCategory, onSelect }) => {
  return (
    <aside className="flex flex-col gap-10">
      <div>
        <h2 className="mb-5 text-[12px] font-medium tracking-[0.25em] text-[#1a1a1a] uppercase">
          Categories
        </h2>

        <ul className="flex flex-col">
          <CategoryItem
            label="All Products"
            count={totalCount}
            active={activeCategory === null}
            onClick={() => onSelect(null)}
          />
          {categories.map((category) => (
            <CategoryItem
              key={category.name}
              label={category.name}
              count={category.count}
              active={activeCategory === category.name}
              onClick={() => onSelect(category.name)}
            />
          ))}
        </ul>
      </div>

      <div className="relative overflow-hidden bg-black px-7 py-9">
        <img
          src="/Hero-image/00.png"
          alt=""
          aria-hidden="true"
          className="absolute inset-0 h-full w-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-black/70" />

        <div className="relative z-10">
          <p className="font-display text-[24px] leading-[1.1] font-medium text-white">
            <span className="block">NEED</span>
            <span className="block">ASSISTANCE?</span>
          </p>
          <p className="mt-4 text-[13px] leading-relaxed font-light text-white/75">
            Our team is here to help you find the perfect stone.
          </p>
          <Link
            to="/contact"
            className="group mt-6 inline-flex items-center gap-2 border border-white/40 px-5 py-2.5 text-[11px] font-medium tracking-[0.2em] text-white transition-all duration-300 hover:border-[#c6a97c] hover:bg-[#c6a97c] hover:text-black"
          >
            CONTACT US
            <ArrowRight
              size={13}
              className="transition-transform duration-300 group-hover:translate-x-1"
            />
          </Link>
        </div>
      </div>
    </aside>
  );
};

const CategoryItem = ({ label, count, active, onClick }) => (
  <li>
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={`flex w-full items-center justify-between gap-3 border-l-2 px-4 py-3 text-left text-[13px] tracking-wide uppercase transition-colors duration-300 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-[-2px] focus-visible:outline-[#c6a97c] ${
        active
          ? "border-[#c6a97c] bg-[#f5f4f2] font-medium text-[#1a1a1a]"
          : "border-transparent font-light text-[#5c564d] hover:bg-[#f9f8f6]"
      }`}
    >
      <span>{label}</span>
      <span className="text-[12px] font-light text-[#8a7358]">{count}</span>
    </button>
  </li>
);

export default CategorySidebar;
