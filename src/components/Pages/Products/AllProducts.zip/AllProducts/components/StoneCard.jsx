import { useState } from "react";
import { Dialog, IconButton } from "@mui/material";
import { ArrowRight, X } from "lucide-react";

const StoneCard = ({ product, index }) => {
  const [imageLoaded, setImageLoaded] = useState(false);
  const [dialogImageLoaded, setDialogImageLoaded] = useState(false);
  const [open, setOpen] = useState(false);

  const handleOpen = () => {
    setDialogImageLoaded(false);
    setOpen(true);
  };

  return (
    <>
      <article
        className="ap-card ap-card-enter group flex flex-col border border-black/10 bg-white"
        style={{ animationDelay: `${Math.min(index, 8) * 60}ms` }}
      >
        <div className="relative overflow-hidden bg-[#f0ede7]">
          {/* The image stays in normal flow (never display:none) so the
              browser's native lazy-load intersection check can see it and
              actually fetch it — the shimmer just overlays on top until load. */}
          <img
            src={product.image}
            alt={product.name}
            loading="lazy"
            onLoad={() => setImageLoaded(true)}
            onError={() => setImageLoaded(true)}
            className={`ap-card-image aspect-[4/5] w-full object-cover transition-opacity duration-500 ${
              imageLoaded ? "opacity-100" : "opacity-0"
            }`}
          />
          {!imageLoaded && (
            <div
              className="ap-shimmer absolute inset-0"
              aria-hidden="true"
            />
          )}
        </div>

        <div className="flex flex-1 flex-col px-5 py-5">
          <h3 className="ap-card-title font-display text-[19px] font-medium tracking-wide text-[#1a1a1a]">
            {product.name}
          </h3>
          <p className="mt-1 text-[11px] font-medium tracking-[0.2em] text-[#8a7358] uppercase">
            {product.category}
          </p>

          <button
            type="button"
            onClick={handleOpen}
            className="mt-auto inline-flex items-center gap-2 self-start pt-6 text-[12px] font-medium tracking-[0.15em] text-[#1a1a1a] uppercase focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#c6a97c]"
            aria-label={`View details for ${product.name}`}
          >
            View Details
            <ArrowRight size={14} className="ap-card-arrow" />
          </button>
        </div>
      </article>

      <Dialog
        open={open}
        onClose={() => setOpen(false)}
        maxWidth="md"
        fullWidth
        slotProps={{
          paper: {
            sx: {
              backgroundColor: "transparent",
              boxShadow: "none",
              overflow: "visible",
              margin: { xs: "12px", sm: "24px" },
            },
          },
        }}
      >
        <IconButton
          onClick={() => setOpen(false)}
          aria-label="Close image"
          sx={{
            position: "absolute",
            top: { xs: "-8px", sm: "-16px" },
            right: { xs: "-8px", sm: "-16px" },
            zIndex: 10,
            width: { xs: "34px", sm: "42px" },
            height: { xs: "34px", sm: "42px" },
            padding: 0,
            color: "#fff",
            backgroundColor: "rgba(0, 0, 0, 0.65)",
            "&:hover": { backgroundColor: "rgba(0, 0, 0, 0.85)" },
          }}
        >
          <X size={20} />
        </IconButton>

        {!dialogImageLoaded && (
          <div
            className="ap-shimmer w-full"
            style={{ height: "70vh" }}
            aria-hidden="true"
          />
        )}

        <div className="bg-white">
          <img
            src={product.image}
            alt={product.name}
            onLoad={() => setDialogImageLoaded(true)}
            onError={() => setDialogImageLoaded(true)}
            className={`w-full object-contain ${
              dialogImageLoaded ? "block" : "hidden"
            }`}
            style={{ maxHeight: "75vh" }}
          />
          <div className="px-6 py-5">
            <h3 className="font-display text-[24px] font-medium text-[#1a1a1a]">
              {product.name}
            </h3>
            <p className="mt-1 text-[11px] font-medium tracking-[0.2em] text-[#8a7358] uppercase">
              {product.category}
            </p>
            {product.description && (
              <p className="mt-4 max-w-2xl text-[14px] leading-relaxed font-light text-[#555]">
                {product.description}
              </p>
            )}
          </div>
        </div>
      </Dialog>
    </>
  );
};

export default StoneCard;
